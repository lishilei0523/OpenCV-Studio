﻿namespace SD.OpenCV.Client.Views.DrawContext
{
    /// <summary>
    /// 绘制矩形视图
    /// </summary>
    public partial class RectangleView
    {
        public RectangleView()
        {
            this.InitializeComponent();
        }
    }
}
