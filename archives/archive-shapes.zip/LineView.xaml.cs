﻿namespace SD.OpenCV.Client.Views.DrawContext
{
    /// <summary>
    /// 绘制线段视图
    /// </summary>
    public partial class LineView
    {
        public LineView()
        {
            this.InitializeComponent();
        }
    }
}
