﻿namespace SD.OpenCV.Client.Views.DrawContext
{
    /// <summary>
    /// 绘制圆形视图
    /// </summary>
    public partial class CircleView
    {
        public CircleView()
        {
            this.InitializeComponent();
        }
    }
}
