﻿namespace SD.OpenCV.Client.Views.DrawContext
{
    /// <summary>
    /// 绘制轮廓视图
    /// </summary>
    public partial class ContourView
    {
        public ContourView()
        {
            this.InitializeComponent();
        }
    }
}
